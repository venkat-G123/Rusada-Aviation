﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace TaskList
{
    class TodoList
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime DueDate { get; set; }
        public int Schedule  { get; set; }
        public int Completed { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }
        public DateTime ScheduleDate { get; set; }
        public DateTime CompletedDate { get; set; }
        public List<TodoList> GetAllTodoList()
        {
            List<TodoList> t = new List<TodoList>();
            return t;
        }
        public void Insert()
        {
            var connection = System.Configuration.ConfigurationManager.ConnectionStrings["con"].ConnectionString;
            SqlConnection scn = new SqlConnection(connection);
            scn.Open();
            string sql = "INSERT INTO TASKDETAILS(Title,Description,CreatedDate,DueDate) VALUES('" + Title + "','" + Description + "','" + Convert.ToDateTime(System.DateTime.Now).ToString("yyyyMMdd") + "','" + Convert.ToDateTime(DueDate).ToString("yyyyMMdd") + "')";
            SqlCommand cmd = new SqlCommand(sql,scn);            
            cmd.ExecuteNonQuery();
            scn.Close();
        }
        public bool DuplicateCheck(string Title)
        {
            bool RecordExist = false;
            var connection = System.Configuration.ConfigurationManager.ConnectionStrings["con"].ConnectionString;
            SqlConnection scn = new SqlConnection(connection);
            scn.Open();
            string sql = "SELECT * FROM TaskDetails WHERE Title ='" + Title + "'";
            SqlCommand cmd = new SqlCommand(sql, scn);
            SqlDataReader sdr = cmd.ExecuteReader();
            if(sdr.Read())
            {
                RecordExist = true;
            }
            scn.Close();
            return RecordExist;
        }
        public void Update(int TaskId)
        {            
            var connection = System.Configuration.ConfigurationManager.ConnectionStrings["con"].ConnectionString;
            SqlConnection scn = new SqlConnection(connection);
            scn.Open();
            string sql = "";
            if (Schedule == 0 && Completed == 0)
                sql = "UPDATE TaskDetails SET Title='" + Title + "',Description='" + Description + "',ModifiedDate='" + Convert.ToDateTime(System.DateTime.Now).ToString("yyyyMMdd") + "',DueDate='" + Convert.ToDateTime(DueDate).ToString("yyyyMMdd") + "' WHERE TaskID=" + TaskId +"";
            else if(Schedule == 1 && Completed == 0)
                sql = "UPDATE TaskDetails SET  Schedule="+ Schedule +",ScheduleDate='" + Convert.ToDateTime(System.DateTime.Now).ToString("yyyyMMdd") + "' WHERE TaskID = " + TaskId +"";
            else if (Schedule == 1 && Completed == 0)
                sql = "UPDATE TaskDetails SET  Completed=" + Completed + ",CompletedDateTime='" + Convert.ToDateTime(System.DateTime.Now).ToString("yyyyMMdd") + "' WHERE TaskID = " + TaskId + "";
            else if (Schedule == 1 && Completed == 1)
                sql = "UPDATE TaskDetails SET  Schedule=" + Schedule + ",ScheduleDate='" + Convert.ToDateTime(System.DateTime.Now).ToString("yyyyMMdd") + "',Completed=" + Completed + ",CompletedDateTime='" + Convert.ToDateTime(System.DateTime.Now).ToString("yyyyMMdd") + "' WHERE TaskID = " + TaskId + "";
            SqlCommand cmd = new SqlCommand(sql, scn);
            cmd.ExecuteNonQuery();
            scn.Close();
        }
        public void Delete(int TaskId)
        {
            var connection = System.Configuration.ConfigurationManager.ConnectionStrings["con"].ConnectionString;
            SqlConnection scn = new SqlConnection(connection);
            scn.Open();           
            string  sql = "DELETE FROM TaskDetails WHERE TaskID=" + TaskId + "";            
            SqlCommand cmd = new SqlCommand(sql, scn);
            cmd.ExecuteNonQuery();
            scn.Close();
        }
        public DataTable LoadData()
        {
            var connection = System.Configuration.ConfigurationManager.ConnectionStrings["con"].ConnectionString;
            SqlConnection scn = new SqlConnection(connection);
            scn.Open();
            string sql = "SELECT Title,Description,DueDate,Schedule,Completed FROM TaskDetails";
            SqlCommand cmd = new SqlCommand(sql, scn);
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            scn.Close();
            return dt;
        }

        public DataTable GetData(int TaskId)
        {
            var connection = System.Configuration.ConfigurationManager.ConnectionStrings["con"].ConnectionString;
            SqlConnection scn = new SqlConnection(connection);
            scn.Open();
            string sql = "SELECT Title,Description,DueDate,Schedule,Completed FROM TaskDetails WHERE TaskID=" + TaskId +"";
            SqlCommand cmd = new SqlCommand(sql, scn);
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            scn.Close();
            return dt;
        }
    }
}
