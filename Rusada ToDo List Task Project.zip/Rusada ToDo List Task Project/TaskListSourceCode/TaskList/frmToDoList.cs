﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TaskList
{
    public partial class frmTODOList : Form
    {
        public frmTODOList()
        {
            InitializeComponent();
        }

        private void frmTODOList_Load(object sender, EventArgs e)
        {
            TodoList t = new TodoList();
            grdTaskList.DataSource= t.LoadData("");            
            colorUpdate();
            Grid_WidthSet();
        }

        private void btnNewTask_Click(object sender, EventArgs e)
        {
            frmTask f = new frmTask(0,false);
            f.ShowDialog();
            f.Close();
            TodoList t = new TodoList();            
            grdTaskList.DataSource = t.LoadData("");
            colorUpdate();
            Grid_WidthSet();
        }

        private void btnUpdateTask_Click(object sender, EventArgs e)
        {
            if(grdTaskList.SelectedRows.Count ==0)
            {
                MessageBox.Show("Please select the Task to update", "Task Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            int TaskId =Convert.ToInt32(grdTaskList.Rows[grdTaskList.CurrentRow.Index].Cells["TaskID"].Value);
            frmTask f = new frmTask(TaskId,false);
            f.ShowDialog();
            TodoList t = new TodoList();
            grdTaskList.DataSource = t.LoadData("");
            colorUpdate();
            Grid_WidthSet();
        }

        private void colorUpdate()
        {
            for(int i=0;i<grdTaskList.Rows.Count;i++)
            {
                if(Convert.ToDateTime(grdTaskList.Rows[i].Cells["DueDate"].Value)<System.DateTime.Today && Convert.ToString(grdTaskList.Rows[i].Cells["Schedule"].Value) =="" )
                {                   
                    grdTaskList.Rows[i].Cells["DueDate"].Style.BackColor = Color.Red; 
                }
                if (Convert.ToString(grdTaskList.Rows[i].Cells["Completed"].Value) != "")
                {
                    grdTaskList.Rows[i].Cells["Completed"].Style.BackColor = Color.Green;
                }
            }
        }
        private void Grid_WidthSet()
        {           
            grdTaskList.Columns["Description"].Width = 300;           
        }
        private void btnView_Click(object sender, EventArgs e)
        {
            if (grdTaskList.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select the Task to View", "Task View", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            int TaskId = Convert.ToInt32(grdTaskList.Rows[grdTaskList.CurrentRow.Index].Cells["TaskID"].Value);
            frmTask f = new frmTask(TaskId,true);
            f.ShowDialog();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (grdTaskList.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select the Task to delete", "Task Delete", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (MessageBox.Show("Are you sure want to delete the selected task", "Task delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            {
                return;    
            }

            int TaskId = Convert.ToInt32(grdTaskList.Rows[grdTaskList.CurrentRow.Index].Cells["TaskID"].Value);
            bool Sdl = false, complete = false;
            if(Convert.ToString(grdTaskList.Rows[grdTaskList.CurrentRow.Index].Cells["Schedule"].Value) !="")
                Sdl = Convert.ToBoolean(grdTaskList.Rows[grdTaskList.CurrentRow.Index].Cells["Schedule"].Value);
            
            if (Convert.ToString(grdTaskList.Rows[grdTaskList.CurrentRow.Index].Cells["completed"].Value) != "")
                complete = Convert.ToBoolean(grdTaskList.Rows[grdTaskList.CurrentRow.Index].Cells["completed"].Value);
            
            if (Sdl == true || complete == true)
            {
                MessageBox.Show("This record cannot be deleted,Because this is already scheduld.", "Task Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            TodoList t = new TodoList();
            t.Delete(TaskId);
            MessageBox.Show("Selected task deleted", "Task Delete", MessageBoxButtons.OK, MessageBoxIcon.Information);
            grdTaskList.DataSource = t.LoadData("");
            colorUpdate();
            Grid_WidthSet();
        }

        private void txtTitle_TextChanged(object sender, EventArgs e)
        {
            TodoList t = new TodoList();
            grdTaskList.DataSource = t.LoadData(txtTitle.Text);
            colorUpdate();
            Grid_WidthSet();
        }
    }
}
