﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace TaskList
{
    class TodoList
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime DueDate { get; set; }
        public int Schedule  { get; set; }
        public int Completed { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }
        public DateTime ScheduleDate { get; set; }
        public DateTime CompletedDate { get; set; }
        public List<TodoList> GetAllTodoList()
        {
            List<TodoList> t = new List<TodoList>();
            return t;
        }
        public void Insert()
        {
            var connection = System.Configuration.ConfigurationManager.ConnectionStrings["con"].ConnectionString;
            SqlConnection scn = new SqlConnection(connection);
            scn.Open();
            string sql = "Insert Into TaskDetails(Title,Description,CreatedDate,DueDate) Values('" + Title + "','" + Description + "','" + System.DateTime.Now + "','" + Convert.ToDateTime(DueDate).ToString("yyyyMMdd") + "')";
            SqlCommand cmd = new SqlCommand(sql,scn);            
            cmd.ExecuteNonQuery();
            scn.Close();
        }
        public bool DuplicateCheck(string Title)
        {
            bool RecordExist = false;
            var connection = System.Configuration.ConfigurationManager.ConnectionStrings["con"].ConnectionString;
            SqlConnection scn = new SqlConnection(connection);
            scn.Open();
            string sql = "select * from TaskDetails where Title ='" + Title + "'";
            SqlCommand cmd = new SqlCommand(sql, scn);
            SqlDataReader sdr = cmd.ExecuteReader();
            if(sdr.Read())
            {
                RecordExist = true;
            }
            scn.Close();
            return RecordExist;
        }
        public void Update(int TaskId)
        {            
            var connection = System.Configuration.ConfigurationManager.ConnectionStrings["con"].ConnectionString;
            SqlConnection scn = new SqlConnection(connection);
            scn.Open();
            string sql = "";
            if (Schedule == 0 && Completed == 0)
                sql = "Update TaskDetails set Title='" + Title + "',Description='" + Description + "',ModifiedDate='" + System.DateTime.Now + "',DueDate='" + Convert.ToDateTime(DueDate).ToString("yyyyMMdd") + "' where TaskId=" + TaskId +"";
            else if(Schedule == 1 && Completed == 0)
                sql = "Update TaskDetails set  Schedule="+ Schedule +",ScheduleDate='" + System.DateTime.Now + "' where TaskID = " + TaskId +"";
            else if (Schedule == 1 && Completed == 0)
                sql = "Update TaskDetails set  Completed=" + Completed + ",CompletedDateTime='" + System.DateTime.Now + "' where TaskID = " + TaskId + "";
            else if (Schedule == 1 && Completed == 1)
                sql = "Update TaskDetails set  Schedule=" + Schedule + ",ScheduleDate='" + System.DateTime.Now + "',Completed=" + Completed + ",CompletedDateTime='" + System.DateTime.Now + "' where TaskID = " + TaskId + "";
            SqlCommand cmd = new SqlCommand(sql, scn);
            cmd.ExecuteNonQuery();
            scn.Close();
        }
        public void Delete(int TaskId)
        {
            var connection = System.Configuration.ConfigurationManager.ConnectionStrings["con"].ConnectionString;
            SqlConnection scn = new SqlConnection(connection);
            scn.Open();           
            string  sql = "delete from TaskDetails where TaskID=" + TaskId + "";            
            SqlCommand cmd = new SqlCommand(sql, scn);
            cmd.ExecuteNonQuery();
            scn.Close();
        }
        public DataTable LoadData()
        {
            var connection = System.Configuration.ConfigurationManager.ConnectionStrings["con"].ConnectionString;
            SqlConnection scn = new SqlConnection(connection);
            scn.Open();
            string sql = "select * from TaskDetails";
            SqlCommand cmd = new SqlCommand(sql, scn);
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            scn.Close();
            return dt;
        }

        public DataTable GetData(int TaskId)
        {
            var connection = System.Configuration.ConfigurationManager.ConnectionStrings["con"].ConnectionString;
            SqlConnection scn = new SqlConnection(connection);
            scn.Open();
            string sql = "select * from TaskDetails where TaskID="+ TaskId +"";
            SqlCommand cmd = new SqlCommand(sql, scn);
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            scn.Close();
            return dt;
        }
    }
}
